var User = require('./../utility/UserDB');
var Connection = require('./../utility/connectionDB');
var mongoose = require('mongoose');
var db = mongoose.connect('mongodb://localhost/HTA_Database',function(error){
    if(error) console.log(error);
});

var Schema = mongoose.Schema;
var userConnectionSchema = new Schema({
User_Id: Number,
connection_ID: Number,
RSVP:String,
});

var UserConnection = mongoose.model('userconnection1',userConnectionSchema);


//get user profile method, connection list from user profile
var getUserProfile=function(User_Id){
    var all=UserConnection.find({User_Id:User_Id});
    all.exec().then(function(docs){
    });
    return all;
  };

//add rsvp method
var addRSVP = function(User_Id,connection_ID,RSVP){
    var addConnection = new UserConnection({User_Id:User_Id,connection_ID: connection_ID, RSVP:RSVP});
  addConnection.save().then(function(docs){
  });
   return addConnection;
  } ;

//remove connection rsvp from user profile
var removeRSVP = function(User_Id,connection_ID,RSVP){
  var query = UserConnection.remove({User_Id:User_Id,connection_ID: connection_ID, RSVP:RSVP});
  query.exec();
}

//update new rsvp value
var updateRSVP = function(User_Id,connectionID, RSVP) {
var connections = UserConnection.update({User_Id:User_Id,connection_ID:connectionID},{$set: {RSVP: RSVP}});
connections.exec().then(function(docs){
});
 return connections;
} ;

//adding a new connection to the database
var addConnection = function(connection_ID,connection_Topic,Datetime,Details,Connection_Cat,location,imageURL,Owner_ID) {
  var newConnection = new Connection({connection_ID: connection_ID, connection_Topic:connection_Topic,
                      Details: Details,
                      Datetime: Datetime, Connection_Cat:Connection_Cat,
                      location: location, imageURL:imageURL,
                      Owner_ID:Owner_ID});
newConnection.save().then(function(docs){
});
 return newConnection;
};

//adding a new user to the database
var addUser = function(User_Id,password,First_Name, Last_Name, email,ADDRESS_1, ADDRESS_2, CITY, STATE, ZIP, COUNTRY) {
  var newUser = new User({User_Id: User_Id, password:password,
                         First_Name: First_Name,
                         Last_Name: Last_Name, email:email,
                         ADDRESS_1: ADDRESS_1, ADDRESS_2:ADDRESS_2,
                         CITY:CITY,
                         STATE: STATE, ZIP:ZIP,COUNTRY:COUNTRY});
newUser.save().then(function(docs){
});
 return newUser;
};


  module.exports = UserConnection;
  module.exports.getUserProfile = getUserProfile;
  module.exports.addRSVP = addRSVP;
  module.exports.removeRSVP = removeRSVP;
  module.exports.updateRSVP = updateRSVP;
  module.exports.addConnection = addConnection;
  module.exports.addUser = addUser;
