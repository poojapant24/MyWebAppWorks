var mongoose = require('mongoose');
//mongoose.connect('mongodb://localhost/HTA_Database', { useNewUrlParser: true });
var db = mongoose.connect('mongodb://localhost/HTA_Database',function(error){
    if(error) console.log(error);
});

var Schema = mongoose.Schema;
var connectionSchema = new Schema({
connection_ID: Number,
connection_Topic:String,
Details:String,
Datetime:String,
Connection_Cat:String,
location:String,
imageURL:String,
Owner_ID:String
});

var Connection = mongoose.model('connection1',connectionSchema);

//get all the connections
    var getConnections = function(){
    var all = Connection.find();
    return all;
  }

//get one connection
  var getConnection=function(connection){
          var all=Connection.find({connection_ID:connection});
          return all;
        };

        //remove connection  from user profile
        var removeConnection = function(connection_ID){
          var query = Connection.remove({connection_ID: connection_ID});
          query.exec();
        };

        //update connection details
        var updateConnection = function(connection_ID,connection_Topic,Details,Datetime,Connection_Cat,location) {
        var updatedConnection = Connection.update({connection_ID:connection_ID},{$set:{connection_Topic:connection_Topic,
                                Details: Details,
                                Datetime: Datetime,
                                Connection_Cat:Connection_Cat,
                                location: location}});
        updatedConnection.exec().then(function(docs){
        });
         return updatedConnection;
        };


  module.exports = Connection;
  module.exports.getConnections = getConnections;
  module.exports.getConnection = getConnection;
  module.exports.removeConnection = removeConnection;
  module.exports.updateConnection = updateConnection;
