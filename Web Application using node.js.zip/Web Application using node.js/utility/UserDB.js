
var mongoose = require('mongoose');
var db = mongoose.connect('mongodb://localhost/HTA_Database',function(error){
    if(error) console.log(error);
});

var Schema = mongoose.Schema;
var userSchema = new Schema({
User_Id: Number,
password:String,
First_Name:String,
Last_Name:String,
email:String,
ADDRESS_1:String,
ADDRESS_2:String,
CITY:String,
STATE:String,
ZIP:String,
COUNTRY:String
});

var User = mongoose.model('user1',userSchema);

//get all the users
  var allUsers = function(){
  var all = User.find();
  return all;
}

//get one user from the database
var getUser = function(user_id){
var all = User.find({User_Id:user_id});
return all;
};

      module.exports = User;
      module.exports.allUsers = allUsers;
      module.exports.getUser = getUser;
