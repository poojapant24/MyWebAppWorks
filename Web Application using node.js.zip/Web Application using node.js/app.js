var express = require('express');
var router = express.Router();
var session = require('express-session');
var bodyParser = require('body-parser');
var app= express();
var urlencodedParser = bodyParser.urlencoded({ extended: true});

app.set('view engine','ejs');
app.use('/assets',express.static('assets'));
app.use(bodyParser.json());
app.use(session({secret: 'awesome',
resave: true,
    saveUninitialized: true}));

var connectionController = require('./routes/connectionController.js');
var profileController = require('./routes/profileController.js');

app.use('/',connectionController);
app.use('/',profileController);



app.listen(3000,function(){
    console.log('app started')
    console.log('listening on port 3000')
});
