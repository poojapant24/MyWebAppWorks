var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
const {check, validationResult} = require('express-validator');
var session = require('express-session');
var urlencodedParser = bodyParser.urlencoded({extended: true});
var User = require('./../utility/UserDB');
var Connection = require('./../utility/connectionDB');
var UserConnection = require('./../utility/UserConnectionDB');
var UserProfile = require('./../models/UserProfile');
//used for auto increment while adding new connection to the dtabase
var new_ID=30;


//Login Page
router.get('/login', function (req, res){
  res.render('Login',{errors:0,user_error:0});
});

//To display all the connections present in the database
//when user is not logged in
router.get('/connections', function (req, res){
  if(req.session.user==undefined){
    var AllConnections = Connection.getConnections();
    AllConnections.then(function(docs){
    req.session.AllConnections=docs;
    res.render('connections', {connections:req.session.AllConnections,User:0});
  });
}

//when user is logged in
else{
  var AllConnections = Connection.getConnections();
  AllConnections.then(function(docs){
  req.session.AllConnections=docs;
  //console.log(req.session.AllConnections);
  res.render('connections', {connections:req.session.AllConnections,User:req.session.user});
})
}
});

//when no parameter is passed with connection, display all connections
router.get('/connection/', function (req, res){
    if(req.params.id==undefined){
      res.redirect('/connections');
    }
    else{
    res.redirect('/connections');
    }
    });


//when parameter is passed with connection
router.get('/connection/:id', function (req, res){
  var array=0;

  //getting all the connections and verifying if connection id is valid and present in the system
  var AllConnections = Connection.getConnections();
  AllConnections.then(function(docs){
  req.session.AllConnections=docs;
  //if connection id is not defined
  if(req.params.id==undefined ){
      res.redirect('/connections');
  }
    //if connection id is  defined
  else{
    //verifying for a connection id that matches in the system
  for(var u=0;u<req.session.AllConnections.length;u++){
    //if match found and user is not logged in
    if(req.params.id==req.session.AllConnections[u].connection_ID && req.session.user==undefined){
      var connection = Connection.getConnection(req.params.id);
      connection.then(function(docs){
        req.session.Connection=docs;
   res.render('connection', {connection:req.session.Connection,User:0});
 })
 }
 //if match found and user is logged in
    else if(req.params.id==req.session.AllConnections[u].connection_ID && req.session.user!=undefined){
      var connection = Connection.getConnection(req.params.id);
      connection.then(function(docs){
        req.session.Connection=docs;
  res.render('connection', {connection:req.session.Connection,User:req.session.user});
})
    }
    //if no match found redirecting it to the connections page
    else{
      array=array+1;
      if(req.session.AllConnections.length==array){
          res.redirect('/connections');
      }
      else{
        continue;
      }
    }
  }
}
})
});

//for deleting the connection when user is the owner of the connetion:
router.post('/connectiondelete', function (req, res){
  var removeConnection = Connection.removeConnection(req.query.Connection_ID);
  res.redirect('connections');
  });

  //for updating the connection when user is the owner of the connetion:
  router.post('/connectionupdate', function (req, res){
  req.session.updaetConnection=req.query.Connection_ID;
  var connection = Connection.getConnection(req.session.updaetConnection);
  connection.then(function(docs){
  req.session.details=docs;
  res.render('newConnection', {User:req.session.user,errors:0,user_error:0, details:req.session.details});
})
});

//index page
router.get('/', function (req, res){
  res.render('index');
});

//About Page
router.get('/about', function (req, res){
  res.render('about');
});

//Contact Page
router.get('/contact', function (req, res){
  res.render('contact');
});

//Add New connection Page
router.get('/newConnection',function (req, res) {
  //user is not logged in
  if(req.session.user==undefined){
    res.render('newConnection',{User:0,errors:0,user_error:0, details:0});
  }
  //when user is logged in
  else{
    res.render('newConnection',{User:req.session.user,errors:0,user_error:0,details:0});
  }
});

//post method for starting a new connection
router.post('/newConnection',urlencodedParser,[
  check('topic').not().isIn(['']).withMessage("Topic can not be Null"),
  check('datetime').not().isIn(['']).withMessage("Datetime can not be Null"),
  check('details').not().isIn(['']).withMessage("Details can not be Null"),
  check('category').not().isIn(['']).withMessage("Category can not be Null"),
  check('location').not().isIn(['']).withMessage("Location can not be Null"),
], function (req, res) {
  const errors = validationResult(req);
//if user is not logged in
	if (req.session.user==undefined) {
		res.render('newConnection',{User:0,errors:0,user_error:"You need to login first in order to create a connection", details:0});
	}
  else if (!errors.isEmpty() && req.session.user!=undefined){
    	res.render('newConnection',{User:req.session.user,errors:errors.array(),user_error:0, details:0});
  }
  else
  {
    //when user is logged in
    var loop_count=0;
    //getting all the connections to see if this exists
    var AllConnections = Connection.getConnections();
    AllConnections.then(function(docs){
    req.session.AllConnections=docs;
     for(var x=0; x<req.session.AllConnections.length;x++){
       //match found then update the connection, image and connection id will not be changed
     if(req.session.AllConnections[x].connection_ID==req.session.updaetConnection){
      var updated = Connection.updateConnection(req.session.updaetConnection,req.body.topic,req.body.details,req.body.datetime,
        req.body.category,req.body.location);
      res.redirect('/connections');
     }
     //if no match found when all connection length is max, add new connection
     else{
       loop_count=loop_count+1
       if(loop_count==req.session.AllConnections.length){
         new_ID=new_ID+1;
         //if no field is black in the form, add that connection to the database and redirect to the connections page
             var addedConnection = UserConnection.addConnection(new_ID,req.body.topic,req.body.datetime,req.body.details,req.body.category,
               req.body.location,"/assets/Images/Generic.jpg",req.session.user.User_Id);
             	res.redirect('/connections');
       }
       else{
         continue;
       }
     }
     }
  });
    }
  });

module.exports = router;
