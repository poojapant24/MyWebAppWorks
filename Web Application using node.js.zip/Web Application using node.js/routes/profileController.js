var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
const {check, validationResult} = require('express-validator');
var session = require('express-session');
var urlencodedParser = bodyParser.urlencoded({ extended: true});
var User = require('./../utility/UserDB');
var Connection = require('./../utility/connectionDB');
var UserConnection = require('./../utility/UserConnectionDB');
var UserConnectionNew = require('./../models/UserConnection');
var UserProfile = require('./../models/UserProfile');
var gen_ID=3;



//register, sign up page:

router.get('/Signup',function (req, res) {
    res.render('Signup',{errors:0, success:0});
});

//post method for starting a new connection
router.post('/Signup',urlencodedParser,[
  check('First_Name').not().isIn(['']).withMessage("First Name can not be Null"),
  check('Last_Name').not().isIn(['']).withMessage("Last Name can not be Null"),
  check('ADDRESS_1').not().isIn(['']).withMessage("Address line 1 can not be Null"),
  check('ADDRESS_2').not().isIn(['']).withMessage("Address line 2 can not be Null"),
  check('CITY').not().isIn(['']).withMessage("city can not be Null"),
  check('STATE').not().isIn(['']).withMessage("state can not be Null"),
  check('COUNTRY').not().isIn(['']).withMessage("country can not be Null"),
  check('ZIP').not().isIn(['']).withMessage("zip can not be Null"),
  check('email').isEmail().withMessage("Email should be in email format"),
  check('Password').not().isIn(['']).withMessage("Password can not be Null"),

], function (req, res) {
  const errors = validationResult(req);

  if (!errors.isEmpty()){
    	res.render('Signup',{errors:errors.array(), success:0});
  }
  else
  {
  gen_ID=gen_ID+1;
  //using crypto for encyrting the password
     var crypto = require('crypto');
     var key="TheKey%%123abc";
     var enc_password=crypto.createCipher("aes-256-ctr", key).update(req.body.Password, "utf-8","hex");
      var addedConnection = UserConnection.addUser(gen_ID,enc_password,req.body.First_Name,req.body.Last_Name,req.body.email,
      req.body.ADDRESS_1,req.body.ADDRESS_2,req.body.CITY,req.body.STATE,req.body.ZIP,req.body.COUNTRY);
      	res.render('Signup',{errors:0,success:"User succesfully added"});
    }
});

//Login page, verifying Details
//client and server side validations are applied

router.post('/Login_details',urlencodedParser,[
  check('Username').not().isIn(['']).withMessage("Username can not be Null"),
  check('password').not().isIn(['']).withMessage("Password can not be Null"),
  check('Username').isEmail().withMessage("Username should be in email format"),
],function(req, res){
	const errors = validationResult(req);
	if (!errors.isEmpty()) {
		res.render('Login',{errors:errors.array(),user_error:0});
	}
	else{
    //using crypto to encrypt the password coming from the webpage in order to compare it to save encrypted value
    var crypto = require('crypto');
    var key="TheKey%%123abc";
    var enc_password=crypto.createCipher("aes-256-ctr", key).update(req.body.password, "utf-8","hex");

    var p=0;
		var theUser = User.allUsers();
		user=theUser.exec();
		user.then(function(docs){
			for(var t=0;t<docs.length;t++){
//comparing with encrypted values of password
				if(docs[t].email==req.body.Username && docs[t].password==enc_password){
					req.session.user=docs[t];
					res.redirect('/myConnections');
				}
				else if(docs[t].email==req.body.Username && docs[t].password!=enc_password){
				res.render('Login',{errors:0,user_error:"Password is incorrect"});
				}
				else{
          p=p+1;
          if(p==docs.length){
					res.render('Login',{errors:0,user_error:"Uses does not exists"});
        }
				}
			}
	})
}
});

//ny connections page
router.get('/myConnections',urlencodedParser,function(req, res, next){
	var r=1;
	// user is logged in now
	var all_connection=[];
  var all_RSVP=[];
	 var userConnectionProfile = UserConnection.getUserProfile(req.session.user.User_Id);
	  userConnectionProfile.then(async function(docs){
	   req.session.connection_list=docs;
		 //if user has not added any connection to his profile
		 if (req.session.connection_list.length==0){
			  res.render('myConnections',{userProfile:0, connection:0, User:req.session.user});
		 }
		 //when there are connections in user profile
		 else{
	    var	finalUserProfile_connections = new UserProfile(req.session.user.User_Id, req.session.connection_list);
	     req.session.finalUserProfile_connections=finalUserProfile_connections;

	//getting connection details
	for(var d=0;d<req.session.connection_list.length; d++){
      var get_connection = Connection.getConnection(req.session.connection_list[d].connection_ID);
      //all_RSVP.push(req.session.connection_list[d].RSVP);
await get_connection.then(function(docs){
	   all_connection.push(docs);
	    if(r==req.session.connection_list.length){
		   req.session.all_connection=all_connection;
		 res.render('myConnections',{userProfile:req.session.finalUserProfile_connections, connection:req.session.all_connection, User:req.session.user});
		next();
	 }
		 r=r+1;
   });
}
}
})
});

//check the session for upcoming action and task values and get connection Id from parameters:
router.post('/myConnections',urlencodedParser,function(req, res){
	//when no user is logged in
	if (req.session.user==undefined){
		res.render('myConnections',{userProfile:0, connection:0, User:0});
	}

	//when user is logged in
	else{
//for task yes
if(req.query.action=='save' && req.query.task=='yes'){
	var userConnectionProfile = UserConnection.getUserProfile(req.session.user.User_Id);
	 userConnectionProfile.then(function(docs){
		req.session.connection_list=docs;
		//if the connection list is blank, add new connection
		if(req.session.connection_list.length==[]){
			var userconnection=UserConnection.addRSVP(req.session.user.User_Id,req.query.Connection_ID,'Yes');
			res.redirect('/myConnections');
			}
			//if connection list is not blank
			else{
				var j=0;
				for(i=0;i<req.session.connection_list.length;i++){
					//if match found for that record,update it.
					if(req.session.connection_list[i].connection_ID==req.query.Connection_ID){
						var userconnection=UserConnection.updateRSVP(req.session.user.User_Id,req.session.connection_list[i].connection_ID,'Yes');
						res.redirect('/myConnections');
					}
					//if no match found for that connection id, add it
				else{
					j=j+1;
					if(j==req.session.connection_list.length){
						var userconnection=UserConnection.addRSVP(req.session.user.User_Id,req.query.Connection_ID,'Yes');
						res.redirect('/myConnections');
				}
				else{
					continue;
				}
			}
			}
			}
	})
}

//for task No:
else if(req.query.action=='save' && req.query.task=='no'){
	var userConnectionProfile = UserConnection.getUserProfile(req.session.user.User_Id);
	 userConnectionProfile.then(function(docs){
		req.session.connection_list=docs;
		//if connection list is blank, add new rsvp for that
		if(req.session.connection_list.length==[]){
			var userconnection=UserConnection.addRSVP(req.session.user.User_Id,req.query.Connection_ID,'No');
			res.redirect('/myConnections');
			}
			//when connection list in user profile is not blank
			else{
				var j=0;
				for(i=0;i<req.session.connection_list.length;i++){
					//if match found, update it
					if(req.session.connection_list[i].connection_ID==req.query.Connection_ID){
						var userconnection=UserConnection.updateRSVP(req.session.user.User_Id,req.session.connection_list[i].connection_ID,'No');
						res.redirect('/myConnections');
					}
					//if no match found, add it
				else{
					j=j+1;
					if(j==req.session.connection_list.length){
						var userconnection=UserConnection.addRSVP(req.session.user.User_Id,req.query.Connection_ID,'No');
						res.redirect('/myConnections');
				}
				else{
					continue;
				}
			}
			}
			}
	})
}

//for task Maybe:
else if(req.query.action=='save' && req.query.task=='maybe'){
	var userConnectionProfile = UserConnection.getUserProfile(req.session.user.User_Id);
	 userConnectionProfile.then(function(docs){
		req.session.connection_list=docs;
		//if connection list is blank, add that new rsvp
		if(req.session.connection_list.length==[]){
			var userconnection=UserConnection.addRSVP(req.session.user.User_Id,req.query.Connection_ID,'Maybe');
			res.redirect('/myConnections');
			}
			//when connection list is not blank
			else{
				var j=0;
				for(i=0;i<req.session.connection_list.length;i++){
					//if match found, update it
					if(req.session.connection_list[i].connection_ID==req.query.Connection_ID){
						var userconnection=UserConnection.updateRSVP(req.session.user.User_Id,req.session.connection_list[i].connection_ID,'Maybe');
						res.redirect('/myConnections');
					}
					//if no match found, add it
				else{
					j=j+1;
					if(j==req.session.connection_list.length){
						var userconnection=UserConnection.addRSVP(req.session.user.User_Id,req.query.Connection_ID,'Maybe');
						res.redirect('/myConnections');
				}
				else{
					continue;
				}
			}
			}
			}
	})
}

//for action=update RSVP, redirecting to connection page to update new RSVP value:
else if(req.query.Action=='updateRSVP'){
 req.session.Connection_ID=req.query.Connection_ID;
  connection=Connection.getConnection(req.session.Connection_ID);
   connection.then(function(docs){
	  req.session.Connection=docs;

  res.render('connection', {connection:req.session.Connection,User:req.session.user});
})
}

//for action=delete:
else if(req.query.Action=='delete'){
req.session.connection_ID=req.query.Connection_ID;
req.session.RSVP=req.query.RSVP;
var userconnec=UserConnection.removeRSVP(req.session.user.User_Id,req.session.connection_ID,req.session.RSVP);
res.redirect('/myConnections');
}


else{
	res.render('myConnections');
}	}
});

//for logout, destroy the session
router.get('/index',urlencodedParser,function(req, res,next){
			req.session.destroy();
			res.render('index');
			next();
		});

module.exports = router;
