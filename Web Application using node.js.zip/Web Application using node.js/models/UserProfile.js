var User = require('./../models/User');
var UserConnection = require('./../models/UserConnection');
var connection = require('./../models/Connection');
var connectionDB = require('./../utility/connectionDB');
var UserDB = require('./../utility/UserDB');


class UserProfile{
  constructor(User_Id, connection_list){
  this.User_Id=User_Id;
  this.connection_list=connection_list;
}

//methods:

  //get connections method_1--using hard coded data for now
 getConnections(User_Id){
   var UserConnection_1 = new UserConnection(10,'Yes');
   var UserConnection_2 = new UserConnection(20,'No');
  var connection_list=[UserConnection_1,UserConnection_2]
   return connection_list;
 };

   //get connections method_2--for future use
 getConnections(UserPfofile){
   return UserPfofile.connection_list;
 };

//add connection
//verifying if a connection is already present in the connection list.
addConnection(connection_list,Connection,RSVP){
  console.log(connection_list);
  if(connection_list.length==[]){
      var UserConnection_1 = new UserConnection(Connection,RSVP);
      //return UserConnection_1;
      connection_list.push(UserConnection_1);
      return connection_list;
    }

  else{
    var j=0;
    for(i=0;i<connection_list.length;i++){
      if(connection_list[i].Connection==Connection && connection_list[i].RSVP==RSVP){
        return connection_list;
      }
      else if (connection_list[i].Connection==Connection && connection_list[i].RSVP!=RSVP){
        connection_list[i].RSVP=RSVP;
        return connection_list;
    }
    else if(connection_list[i].Connection!=Connection) {
      j=j+1;
      if(j==connection_list.length){
      var UserConnection_1 = new UserConnection(Connection,RSVP);
      //return UserConnection_1;
      connection_list.push(UserConnection_1);
      return connection_list;
    }
    else{
      continue;
    }
  }
  }
  }
};

//update connection method
updateConnection(UserConnection, RSVP){
  UserConnection.Connection =UserConnection.Connection;
  UserConnection.RSVP=RSVP;
  return UserConnection
};

//remove connection method
removeConnection(connection_list,UserConnection){
for (j=0;j<connection_list.length; j++){
        if(connection_list[j].Connection==UserConnection.Connection){
            connection_list.splice(j,1);
            console.log(connection_list);
            return connection_list;
    }
}
};

//empty profile
emptyProfile(userProfile){
    userProfile.connection_list=[];
    return userProfile;
};

};


module.exports = UserProfile;
