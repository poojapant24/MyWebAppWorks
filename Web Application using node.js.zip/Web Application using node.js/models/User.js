
class User{
  constructor(User_Id,password,First_Name, Last_Name, email,ADDRESS_1, ADDRESS_2, CITY, STATE, ZIP, COUNTRY){
  this.User_Id=User_Id;
  this.password=password;
  this.First_Name=First_Name;
  this.Last_Name=Last_Name;
  this.email=email;
  this.ADDRESS_1=ADDRESS_1;
  this.ADDRESS_2=ADDRESS_2;
  this.CITY=CITY;
  this.STATE=STATE;
  this.ZIP=ZIP;
  this.COUNTRY=COUNTRY;
}
};

module.exports = User;
