

class UserConnection{
  constructor(Connection, RSVP){
  this.Connection=Connection;
  this.RSVP=RSVP;
}
};

module.exports = UserConnection;
