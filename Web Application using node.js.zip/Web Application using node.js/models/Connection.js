
class connection{
  constructor(connection_ID, connection_Topic, Datetime, Connection_Cat,location, imageURL,Owner_ID){
  this.connection_ID=connection_ID;
  this.connection_Topic=connection_Topic;
  this.Details=Details,
  this.Datetime=Datetime;
  this.Connection_Cat=Connection_Cat;
  this.location=location;
  this.imageURL=imageURL;
  this.Owner_ID=Owner_ID;
}
};

module.exports=connection;
